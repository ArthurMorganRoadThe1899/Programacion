public class B_JAA2 {
    public static void main(String[] args) {
        int num = 0;
        while (num < 200) {
            num++;
            num++;
            System.out.println(num);
        }
    }
}

// Hecho por Jose Alba Arrufat //
