public class B_JAA3 {
    public static void main(String[] args) {
        int num = 1;
        while (num < 200) {
            num++;
            System.out.println(num++);
        }
    }
}

// Hecho por Jose Alba Arrufat //
