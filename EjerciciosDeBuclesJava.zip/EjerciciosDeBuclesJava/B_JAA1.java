public class B_JAA1 {
    public static void main(String[] args) {
        int num = 0;
        while (num < 20) {
            num++;
            System.out.println(num);
        }
    }
}

// Hecho por Jose Alba Arrufat //
